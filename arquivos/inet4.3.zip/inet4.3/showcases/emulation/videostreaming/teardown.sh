# destroy TAP interfaces
sudo ip tuntap del mode tap dev tapa
sudo ip tuntap del mode tap dev tapb
