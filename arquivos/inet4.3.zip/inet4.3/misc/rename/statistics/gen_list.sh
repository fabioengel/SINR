#!/bin/sh

find ../../../src -name "*.ned" >filelist.txt
