// Generated file, do not edit
#ifndef WITH_OSG
#define WITH_OSG
#endif
