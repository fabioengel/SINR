//
// Generated file, do not edit!
//
// This file defines symbols contributed by the currently active project features,
// and it is regenerated every time a project feature is enabled or disabled.
// See the Project Features dialog in the IDE, and opp_featuretool.
//
#ifndef INET_WITH_ACKINGMAC
#define INET_WITH_ACKINGMAC
#endif

#ifndef INET_WITH_AODV
#define INET_WITH_AODV
#endif

#ifndef INET_WITH_APSKRADIO
#define INET_WITH_APSKRADIO
#endif

#ifndef INET_WITH_BGPv4
#define INET_WITH_BGPv4
#endif

#ifndef INET_WITH_BMAC
#define INET_WITH_BMAC
#endif

#ifndef INET_WITH_CSMACAMAC
#define INET_WITH_CSMACAMAC
#endif

#ifndef INET_WITH_DHCP
#define INET_WITH_DHCP
#endif

#ifndef INET_WITH_DIFFSERV
#define INET_WITH_DIFFSERV
#endif

#ifndef INET_WITH_DSDV
#define INET_WITH_DSDV
#endif

#ifndef INET_WITH_DYMO
#define INET_WITH_DYMO
#endif

#ifndef INET_WITH_EIGRP
#define INET_WITH_EIGRP
#endif

#ifndef INET_WITH_ETHERNET
#define INET_WITH_ETHERNET
#endif

#ifndef INET_WITH_FLOODING
#define INET_WITH_FLOODING
#endif

#ifndef INET_WITH_IEEE80211
#define INET_WITH_IEEE80211
#endif

#ifndef INET_WITH_IEEE802154
#define INET_WITH_IEEE802154
#endif

#ifndef INET_WITH_IEEE8021AE
#define INET_WITH_IEEE8021AE
#endif

#ifndef INET_WITH_IEEE8021D
#define INET_WITH_IEEE8021D
#endif

#ifndef INET_WITH_IEEE8021Q
#define INET_WITH_IEEE8021Q
#endif

#ifndef INET_WITH_IEEE8022
#define INET_WITH_IEEE8022
#endif

#ifndef INET_WITH_IPv4
#define INET_WITH_IPv4
#endif

#ifndef INET_WITH_IPv6
#define INET_WITH_IPv6
#endif

#ifndef INET_WITH_LMAC
#define INET_WITH_LMAC
#endif

#ifndef INET_WITH_MPLS
#define INET_WITH_MPLS
#endif

#ifndef INET_WITH_NEXTHOP
#define INET_WITH_NEXTHOP
#endif

#ifndef INET_WITH_OSPFv2
#define INET_WITH_OSPFv2
#endif

#ifndef INET_WITH_OSPFv3
#define INET_WITH_OSPFv3
#endif

#ifndef INET_WITH_PACKETDRILL
#define INET_WITH_PACKETDRILL
#endif

#ifndef INET_WITH_PHYSICALLAYERCOMMON
#define INET_WITH_PHYSICALLAYERCOMMON
#endif

#ifndef INET_WITH_PHYSICALLAYERWIREDCOMMON
#define INET_WITH_PHYSICALLAYERWIREDCOMMON
#endif

#ifndef INET_WITH_PHYSICALLAYERWIRELESSCOMMON
#define INET_WITH_PHYSICALLAYERWIRELESSCOMMON
#endif

#ifndef INET_WITH_PIM
#define INET_WITH_PIM
#endif

#ifndef INET_WITH_POWER
#define INET_WITH_POWER
#endif

#ifndef INET_WITH_PPP
#define INET_WITH_PPP
#endif

#ifndef INET_WITH_PROTOCOLSUPPORT
#define INET_WITH_PROTOCOLSUPPORT
#endif

#ifndef INET_WITH_QUEUEING
#define INET_WITH_QUEUEING
#endif

#ifndef INET_WITH_RIP
#define INET_WITH_RIP
#endif

#ifndef INET_WITH_RTP
#define INET_WITH_RTP
#endif

#ifndef INET_WITH_SCTP
#define INET_WITH_SCTP
#endif

#ifndef INET_WITH_SHORTCUT
#define INET_WITH_SHORTCUT
#endif

#ifndef INET_WITH_TCP_COMMON
#define INET_WITH_TCP_COMMON
#endif

#ifndef INET_WITH_TCP_INET
#define INET_WITH_TCP_INET
#endif

#ifndef INET_WITH_TUN
#define INET_WITH_TUN
#endif

#ifndef INET_WITH_UDP
#define INET_WITH_UDP
#endif

#ifndef INET_WITH_UNITDISKRADIO
#define INET_WITH_UNITDISKRADIO
#endif

#ifndef INET_WITH_VIRTUALINTERFACE
#define INET_WITH_VIRTUALINTERFACE
#endif

#ifndef INET_WITH_VISUALIZATIONCANVAS
#define INET_WITH_VISUALIZATIONCANVAS
#endif

#ifndef INET_WITH_VISUALIZATIONCOMMON
#define INET_WITH_VISUALIZATIONCOMMON
#endif

#ifndef INET_WITH_WIRELESSNOISESOURCE
#define INET_WITH_WIRELESSNOISESOURCE
#endif

#ifndef INET_WITH_XMAC
#define INET_WITH_XMAC
#endif

#ifndef INET_WITH_xMIPv6
#define INET_WITH_xMIPv6
#endif

