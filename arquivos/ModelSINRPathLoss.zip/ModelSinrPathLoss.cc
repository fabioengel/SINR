//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "inet/physicallayer/wireless/common/pathloss/ModelSinrPathLoss.h"
#include <iostream>
using namespace std;

namespace inet {

namespace physicallayer {

Define_Module(ModelSinrPathLoss);

ModelSinrPathLoss::ModelSinrPathLoss() :
    alpha(4.0),
    systemLoss(1.0)
{
}

void ModelSinrPathLoss::initialize(int stage)
{
    if (stage == INITSTAGE_LOCAL) {
        alpha = par("alpha");
        systemLoss = math::dB2fraction(par("systemLoss"));
    }
}

std::ostream& ModelSinrPathLoss::printToStream(std::ostream& stream, int level) const
{
    stream << "FreeSpacePathLoss";
    if (level <= PRINT_LEVEL_TRACE)
        stream << ", alpha = " << alpha
               << ", systemLoss = " << systemLoss;
    return stream;
}

double ModelSinrPathLoss::computeModelSinrPathLoss(m waveLength, m distance, double alpha, double systemLoss) const
{
    // factor = waveLength ^ 2 / (16 * PI ^ 2 * systemLoss * distance ^ alpha)
    //return distance.get() == 0.0 ? 1.0 : (waveLength * waveLength).get() / (16 * M_PI * M_PI * systemLoss * pow(distance.get(), alpha));
    double pathloss = pow(distance.get(), alpha * -1); //para que possa multiplicar pela potência de transmissão
    //cout << "pathloss: " << pathloss <<  "  dist: " << distance.get()<< endl;
    return distance.get() == 0.0 ? 1.0 : pathloss;
}

double ModelSinrPathLoss::computePathLoss(mps propagationSpeed, Hz frequency, m distance) const
{
    m waveLength = propagationSpeed / frequency;
    return computeModelSinrPathLoss(waveLength, distance, alpha, systemLoss);
}

m ModelSinrPathLoss::computeRange(mps propagationSpeed, Hz frequency, double loss) const
{
    // distance = (waveLength ^ 2 / (16 * PI ^ 2 * systemLoss * loss)) ^ (1 / alpha)
//    m waveLength = propagationSpeed / frequency;
//    cout << "Range Free: " << pow((waveLength * waveLength).get() / (16.0 * M_PI * M_PI * systemLoss * loss), 1.0 / alpha) << endl;
//    return m(pow((waveLength * waveLength).get() / (16.0 * M_PI * M_PI * systemLoss * loss), 1.0 / alpha));
    double range =  pow((power/(N0 * sinrThreshold)), 1/alpha);
    return(m(range));
}

} // namespace physicallayer

} // namespace inet

